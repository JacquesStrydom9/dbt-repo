
-- PART 1
-- TASK: Create a dimension model for patients
-- Reference raw_patients and stg_claims
-- Enrich patients with:
--   - First claim date
--   - Total number of claims
--   - Total claim amount
--   - Days since first claim

with patients as (
    select * from {{ ref('raw_patients') }}
),

-- Add your logic here to join with stg_claims

final as (
    select 
        p.patient_id,
        p.name,
        p.date_of_birth,
        p.gender,
        c.first_claim_date,
        c.total_claims,
        c.total_claim_amount,
        c.days_since_first_claim
    from patients p
    left join (
        select 
            patient_id,
            min(claim_date) as first_claim_date,
            count(claim_id) as total_claims,
            sum(claim_amount) as total_claim_amount,
            datediff('day', min(claim_date), CURRENT_DATE()) as days_since_first_claim
        from {{ ref('stg_claims') }}
        group by patient_id
    ) c on p.patient_id = c.patient_id
)

select * 
from final