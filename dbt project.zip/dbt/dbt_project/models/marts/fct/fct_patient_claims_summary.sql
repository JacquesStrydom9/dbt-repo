

with patients as (
    select * from {{ ref('raw_patients') }}
),

final as (
    select 
        p.name,
        p.date_of_birth,
        p.gender,
        c.claim_id,
        c.patient_id,
        c.claim_date,
        c.claim_amount,
        c.diagnosis_code,
        c.claim_month
    from patients p
    left join (
        select 
            claim_id,
            patient_id,
            cast(claim_date as date) as claim_date,
            cast(claim_amount as numeric) as claim_amount,
            diagnosis_code,
            date_trunc('month', cast(claim_date as date)) as claim_month
        from {{ ref('stg_claims') }}
        --group by patient_id
    ) c on p.patient_id = c.patient_id
    group by  
        p.name,
        p.date_of_birth,
        p.gender,
        c.claim_id,
        c.patient_id,
        c.claim_date,
        c.claim_amount,
        c.diagnosis_code,
        c.claim_month
)
select distinct *
from final