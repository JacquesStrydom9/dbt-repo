docker build -t dbt-project .
docker run -it --rm dbt-project